ULTRA-LOW-POWER LoRa/GPS TRACKER NODE - FABRICATION PACKAGE
==========================================================

Board   : 60.0 x 45.0 mm, 2 layers, FR4, 1.6 mm, 1 oz copper
Finish  : green solder mask, white silkscreen, lead-free HASL
Drill   : 0.3 mm vias, 1.0 mm header pins, 2.7 mm NPTH mounting

GERBER FILES (RS-274X, millimetres, 4.6 format, X2 file functions)
  F.Cu         LoRaTracker-F_Cu.GTL
  B.Cu         LoRaTracker-B_Cu.GBL
  F.Mask       LoRaTracker-F_Mask.GTS
  B.Mask       LoRaTracker-B_Mask.GBS
  F.SilkS      LoRaTracker-F_Silkscreen.GTO
  B.SilkS      LoRaTracker-B_Silkscreen.GBO
  Edge.Cuts    LoRaTracker-Edge_Cuts.GKO
  drill: LoRaTracker-PTH.DRL (plated), LoRaTracker-NPTH.DRL (non-plated)

STACK-UP
  L1  F.Cu     signal + GND pour
  L2  B.Cu     GND pour (near solid ground reference)
  --  Edge.Cuts 60 x 45 mm outline

MANUFACTURING NOTES
  * 4 x M2.5 mounting holes, 2.7 mm NPTH, 3 mm inset from each corner.
  * Minimum track 0.20 mm, minimum clearance 0.20 mm, minimum drill 0.30 mm:
    inside every standard 2-layer prototype process.
  * The ESP32-WROOM-32E PCB antenna overhangs the top board edge; the
    antenna keep-out carries NO copper on either layer.
  * The Ra-02 IPEX antenna end is kept clear on both layers.
  * No controlled impedance required (433 MHz LoRa + external GPS module).
  * Solder mask expansion 0.05 mm per side.

DRC RESULT: 0 errors, 0 warnings
  Full report: LoRaTracker-drc-report.txt

ROUTING: 86 track segments, 40 signal vias, 197 GND stitching vias

The Gerbers, the drill files and the .kicad_pcb are produced from the same
geometry by the pcbgen toolchain, so they are guaranteed to agree.
